const objectsResponse = await fetch('objects.json');
const collectiblesResponse = await fetch('collectibles.json');
